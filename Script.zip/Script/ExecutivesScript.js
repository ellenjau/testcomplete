﻿function ExecutivesScript(Front_url, Lang_url, Back_url)
{
 
  KeywordTests.Executives_Navi.Run(Front_url+Lang_url+Back_url);
  KeywordTests.Executives.Run();
 

}