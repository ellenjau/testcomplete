﻿function ValueScript(Front_url, Lang_url, Back_url)
{
 
  KeywordTests.Value_Navi.Run(Front_url+Lang_url+Back_url);
  KeywordTests.ValueChain.Run();
 
  
}