﻿function Manufact(Front_url, Lang_url, Back_url)
{
  KeywordTests.Manufact_Navi.Run(Front_url+Lang_url+Back_url);
  KeywordTests.Manufact_Check.Run();

}

