﻿function Logic_Check(Front_url, Lang_url, Back_url)
{
  KeywordTests.Logic_Navi.Run(Front_url+Lang_url+Back_url);
  KeywordTests.Logic_Check.Run();
}
 