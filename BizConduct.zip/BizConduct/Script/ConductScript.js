﻿function ConductScript(Front_url, Lang_url, Back_url)
{
  KeywordTests.Conduct_Navi.Run(Front_url+Lang_url+Back_url);
  KeywordTests.ConductAll.Run();
}