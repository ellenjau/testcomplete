﻿function DCAScript(Front_url,Lang_url,Back_url)
{
  KeywordTests.DCA_Navi.Run(Front_url+Lang_url+Back_url);
  KeywordTests.DCA.Run();
}