﻿function Biz_Script(Front_url, Lang_url, Back_url)
{
  KeywordTests.Biz_Navi.Run(Front_url+Lang_url+Back_url);
  KeywordTests.BizContact.Run();
}